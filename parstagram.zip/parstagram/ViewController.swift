//
//  ViewController.swift
//  parstagram
//
//  Created by Maria Evelin Anda-Murillo on 2/25/19.
//  Copyright © 2019 Maria Evelin Anda-Murillo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

