//
//  CommentCell.swift
//  parstagram
//
//  Created by Maria Evelin Anda-Murillo on 3/25/19.
//  Copyright © 2019 Maria Evelin Anda-Murillo. All rights reserved.
//

import UIKit

class CommentCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    
    
    @IBOutlet weak var commentLabel: UILabel!
    
    
    @IBOutlet weak var nameLabel: UILabel!
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
